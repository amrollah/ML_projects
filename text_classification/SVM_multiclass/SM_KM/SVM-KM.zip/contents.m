% Contents    Kernel Methods package
%

% 
% cout.m
% 
% 
% svmclass.m
% 
% 
% 
% svmreg.m
% 
% givrot.m
% 
% 
% 
% svmkernel.m
% 
% 
% 
% monqp.m
% 
% 
% 
% svmclassnpa.m
% 
% 
% 
% svmval.m
% 
% 
% 
% svmmulticlass.m
% 
% 
% 
% svmmultival.m
% 
% 
% 
% functioneval.m
% 
% 
% 
% 
% 
% 
% waveletspan.m
% 
% 
% 
% 
% 
% phispan.m
% 
% 
% 
% 
% regsolve.m
% 
% 
% 
% 
% dataset.m
% 
% 
% 
% 
% rncalc.m
% 
% 
% 
% 
% rnval.m
% 
% 
% 
% 
% monqpCinfty.m
% 
% 
% 
% 
% svmclassLS.m
% 
% 
% 
% svmclassL2.m
% 
% 
% gda.m
% 
% 
% 
% kernelpcaproj.m
% 
% 
% 
% license.txt
% 
% 
% 
% svmnureg.m
% 
% 
% 
% spanestimate.m
% 
% 
% 
% svmmultivaloneagainstone.m
% 
% 
% 
% svmmulticlassoneagainstall.m
% 
% 
% 
% kernelpca.m
% 
% 
% svmmulticlassoneagainstone.m
% 
